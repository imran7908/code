import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import "./App.css";

const host = "http://task.atiar.info/api";
const App = () => {
  return (
    <div className="container">
      <Routes>
        <Route path="/" element={<Home host={host} />} exact />
      </Routes>
    </div>
  );
};

export default App;
