import React, { useEffect, useState } from "react";
import axios from "axios";
import Item from "./Item";
import "./Home.css";

const Home = ({ host }) => {
  const [items, setItems] = useState([]);

  const fetchHandler = async () => {
    return await axios.get(`${host}/todo`).then((res) => res.data);
  };

  useEffect(() => {
    fetchHandler().then((data) => setItems(data.data));
  }, []);

  return (
    <div className="itemsContainer">
      <button className="addTodoButton">Add ToDo</button>
      {items &&
        items.map((item, index) => {
          return <Item item={item} key={index} />;
        })}
    </div>
  );
};

export default Home;
