import React from "react";
import "./Item.css";

const Item = ({ title, note, start_date, start_time, end_date, end_time }) => {
  return <div className="itemContainer"></div>;
};

export default Item;
